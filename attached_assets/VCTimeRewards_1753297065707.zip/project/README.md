# VCTimeRewards

A comprehensive Minecraft plugin that rewards players based on their Discord voice channel activity time. This plugin integrates with DiscordSRV to track when linked players join and leave specific voice channels, then grants configurable in-game rewards based on time milestones.

## Features

### 🎯 Core Functionality
- **DiscordSRV Integration**: Seamlessly hooks into DiscordSRV's official API
- **Voice Channel Tracking**: Monitors specific Discord voice channels (configurable by channel ID)
- **Time-Based Rewards**: Grant rewards when players reach configurable time milestones
- **Persistent Data**: Supports both SQLite and MySQL databases
- **Anti-AFK Options**: Configurable options to ignore muted/deafened users
- **Online Requirement**: Optional requirement for players to be online in Minecraft while in VC

### 🎁 Reward System
- **Configurable Tiers**: Define custom reward tiers in `rewards.yml`
- **Multiple Commands**: Execute multiple commands per reward tier
- **Placeholder Support**: Use `%player%` placeholder in reward commands
- **Flexible Rewards**: Support for items, money, commands, broadcasts, etc.

### 📊 Statistics & Placeholders
- **Player Statistics**: View detailed VC time stats with `/vctime stats`
- **PlaceholderAPI Support**: Full integration with extensive placeholders
- **Real-time Tracking**: Live session tracking and total time accumulation

## Installation

1. **Prerequisites**:
   - Paper/Spigot 1.21+ server
   - Java 17+
   - DiscordSRV plugin installed and configured

2. **Download**: Place the VCTimeRewards.jar file in your `plugins/` folder

3. **Configuration**: 
   - Start your server to generate default configs
   - Configure Discord channel IDs in `config.yml`
   - Customize rewards in `rewards.yml`
   - Restart your server

## Configuration

### config.yml
```yaml
# Database configuration
database:
  type: "sqlite"  # sqlite or mysql
  mysql:
    host: "localhost"
    port: 3306
    database: "vctime"
    username: "root"
    password: ""

# Discord settings
discord:
  tracked-channels:
    - "123456789012345678"  # Your Discord voice channel IDs
  ignore-when-muted: true
  ignore-when-deafened: true
  require-minecraft-online: false

# General settings
settings:
  debug: false
  save-interval: 300
```

### rewards.yml
```yaml
rewards:
  30:  # 30 minutes
    enabled: true
    commands:
      - "give %player% diamond 5"
      - "tell %player% Thanks for 30 minutes in VC!"
  
  60:  # 1 hour
    enabled: true
    commands:
      - "give %player% emerald 10"
      - "eco give %player% 100"
      - "tell %player% 1-hour VC reward!"
```

## Commands

| Command | Permission | Description |
|---------|------------|-------------|
| `/vctime` | `vctime.use` | Show your VC statistics |
| `/vctime stats [player]` | `vctime.stats` | View VC statistics |
| `/vctime reload` | `vctime.reload` | Reload configuration |
| `/vctime help` | `vctime.use` | Show help message |

## Permissions

| Permission | Default | Description |
|------------|---------|-------------|
| `vctime.use` | `true` | Basic command usage |
| `vctime.stats` | `true` | View statistics |
| `vctime.admin` | `op` | Administrative access |
| `vctime.reload` | `op` | Reload configuration |

## PlaceholderAPI Support

| Placeholder | Description |
|-------------|-------------|
| `%vctime_total%` | Total time formatted (e.g., "2h 35m") |
| `%vctime_total_raw%` | Total time in raw minutes |
| `%vctime_current_session%` | Current session time formatted |
| `%vctime_current_session_raw%` | Current session in raw minutes |
| `%vctime_next_reward%` | Time until next reward |
| `%vctime_next_reward_raw%` | Time until next reward (raw minutes) |
| `%vctime_last_reward%` | Last reward tier reached |
| `%vctime_linked%` | Discord link status ("Yes"/"No") |

## Getting Discord Channel IDs

1. Enable Developer Mode in Discord (User Settings → Advanced → Developer Mode)
2. Right-click on the voice channel you want to track
3. Select "Copy ID"
4. Add the ID to your `config.yml` under `discord.tracked-channels`

## Database Support

### SQLite (Default)
- Automatic setup, no configuration needed
- Data stored in `plugins/VCTimeRewards/data.db`
- Perfect for most servers

### MySQL
- Configure connection details in `config.yml`
- Recommended for networks or high-traffic servers
- Supports connection pooling and better performance

## Support & Development

- **Author**: kiro.java
- **Version**: 1.0.0
- **API Version**: 1.21
- **Requires**: DiscordSRV, Java 17+, Paper 1.21.4+

## Building from Source

```bash
git clone https://github.com/kiro-java/VCTimeRewards.git
cd VCTimeRewards
mvn clean package
```

The compiled plugin will be in the `target/` directory.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

---

**Note**: This plugin requires DiscordSRV to be properly configured with your Discord bot. Make sure your players are linked via DiscordSRV before they can earn VC time rewards.