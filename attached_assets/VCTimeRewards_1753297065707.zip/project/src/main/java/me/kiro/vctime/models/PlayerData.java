package me.kiro.vctime.models;

import java.util.UUID;

public class PlayerData {
    
    private final UUID uuid;
    private String discordId;
    private long totalTime; // in milliseconds
    private long currentSessionStart;
    private int lastRewardTier;
    private boolean inVoiceChannel;
    private long lastUpdated;
    
    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.discordId = null;
        this.totalTime = 0;
        this.currentSessionStart = 0;
        this.lastRewardTier = 0;
        this.inVoiceChannel = false;
        this.lastUpdated = System.currentTimeMillis();
    }
    
    public PlayerData(UUID uuid, String discordId, long totalTime, long currentSessionStart, 
                     int lastRewardTier, boolean inVoiceChannel, long lastUpdated) {
        this.uuid = uuid;
        this.discordId = discordId;
        this.totalTime = totalTime;
        this.currentSessionStart = currentSessionStart;
        this.lastRewardTier = lastRewardTier;
        this.inVoiceChannel = inVoiceChannel;
        this.lastUpdated = lastUpdated;
    }
    
    public void startVoiceSession() {
        this.currentSessionStart = System.currentTimeMillis();
        this.inVoiceChannel = true;
        this.lastUpdated = System.currentTimeMillis();
    }
    
    public void endVoiceSession() {
        if (inVoiceChannel && currentSessionStart > 0) {
            long sessionTime = System.currentTimeMillis() - currentSessionStart;
            this.totalTime += sessionTime;
        }
        this.currentSessionStart = 0;
        this.inVoiceChannel = false;
        this.lastUpdated = System.currentTimeMillis();
    }
    
    public long getCurrentSessionTime() {
        if (inVoiceChannel && currentSessionStart > 0) {
            return System.currentTimeMillis() - currentSessionStart;
        }
        return 0;
    }
    
    public long getTotalTimeWithCurrentSession() {
        return totalTime + getCurrentSessionTime();
    }
    
    // Getters and Setters
    public UUID getUuid() {
        return uuid;
    }
    
    public String getDiscordId() {
        return discordId;
    }
    
    public void setDiscordId(String discordId) {
        this.discordId = discordId;
        this.lastUpdated = System.currentTimeMillis();
    }
    
    public long getTotalTime() {
        return totalTime;
    }
    
    public void setTotalTime(long totalTime) {
        this.totalTime = totalTime;
        this.lastUpdated = System.currentTimeMillis();
    }
    
    public long getCurrentSessionStart() {
        return currentSessionStart;
    }
    
    public void setCurrentSessionStart(long currentSessionStart) {
        this.currentSessionStart = currentSessionStart;
        this.lastUpdated = System.currentTimeMillis();
    }
    
    public int getLastRewardTier() {
        return lastRewardTier;
    }
    
    public void setLastRewardTier(int lastRewardTier) {
        this.lastRewardTier = lastRewardTier;
        this.lastUpdated = System.currentTimeMillis();
    }
    
    public boolean isInVoiceChannel() {
        return inVoiceChannel;
    }
    
    public void setInVoiceChannel(boolean inVoiceChannel) {
        this.inVoiceChannel = inVoiceChannel;
        this.lastUpdated = System.currentTimeMillis();
    }
    
    public long getLastUpdated() {
        return lastUpdated;
    }
    
    public void setLastUpdated(long lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}