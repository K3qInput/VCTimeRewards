package me.kiro.vctime.database;

import me.kiro.vctime.VCTimeRewards;
import me.kiro.vctime.models.PlayerData;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class DatabaseManager {
    
    private final VCTimeRewards plugin;
    private Connection connection;
    private final Map<UUID, PlayerData> playerCache = new HashMap<>();
    
    public DatabaseManager(VCTimeRewards plugin) {
        this.plugin = plugin;
    }
    
    public boolean initialize() {
        try {
            if (plugin.getConfigManager().getDatabaseType().equalsIgnoreCase("mysql")) {
                return initializeMySQL();
            } else {
                return initializeSQLite();
            }
        } catch (SQLException e) {
            plugin.getPluginLogger().error("Failed to initialize database: " + e.getMessage());
            return false;
        }
    }
    
    private boolean initializeSQLite() throws SQLException {
        String url = "jdbc:sqlite:" + plugin.getDataFolder() + "/data.db";
        connection = DriverManager.getConnection(url);
        createTables();
        plugin.getPluginLogger().info("Connected to SQLite database");
        return true;
    }
    
    private boolean initializeMySQL() throws SQLException {
        String host = plugin.getConfigManager().getDatabaseHost();
        int port = plugin.getConfigManager().getDatabasePort();
        String database = plugin.getConfigManager().getDatabaseName();
        String username = plugin.getConfigManager().getDatabaseUsername();
        String password = plugin.getConfigManager().getDatabasePassword();
        
        String url = "jdbc:mysql://" + host + ":" + port + "/" + database + "?useSSL=false&serverTimezone=UTC";
        connection = DriverManager.getConnection(url, username, password);
        createTables();
        plugin.getPluginLogger().info("Connected to MySQL database");
        return true;
    }
    
    private void createTables() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS vctime_data (
                    uuid VARCHAR(36) PRIMARY KEY,
                    discord_id VARCHAR(20),
                    total_time BIGINT DEFAULT 0,
                    current_session_start BIGINT DEFAULT 0,
                    last_reward_tier INT DEFAULT 0,
                    in_voice_channel BOOLEAN DEFAULT FALSE,
                    last_updated BIGINT DEFAULT 0
                )""";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.executeUpdate();
        }
        
        plugin.getPluginLogger().info("Database tables created/verified");
    }
    
    public CompletableFuture<PlayerData> getPlayerData(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            if (playerCache.containsKey(uuid)) {
                return playerCache.get(uuid);
            }
            
            try {
                String sql = "SELECT * FROM vctime_data WHERE uuid = ?";
                try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                    stmt.setString(1, uuid.toString());
                    
                    try (ResultSet rs = stmt.executeQuery()) {
                        PlayerData data;
                        if (rs.next()) {
                            data = new PlayerData(
                                    uuid,
                                    rs.getString("discord_id"),
                                    rs.getLong("total_time"),
                                    rs.getLong("current_session_start"),
                                    rs.getInt("last_reward_tier"),
                                    rs.getBoolean("in_voice_channel"),
                                    rs.getLong("last_updated")
                            );
                        } else {
                            data = new PlayerData(uuid);
                        }
                        
                        playerCache.put(uuid, data);
                        return data;
                    }
                }
            } catch (SQLException e) {
                plugin.getPluginLogger().error("Failed to get player data: " + e.getMessage());
                return new PlayerData(uuid);
            }
        });
    }
    
    public CompletableFuture<Void> savePlayerData(PlayerData data) {
        return CompletableFuture.runAsync(() -> {
            try {
                String sql = """
                        INSERT OR REPLACE INTO vctime_data 
                        (uuid, discord_id, total_time, current_session_start, last_reward_tier, in_voice_channel, last_updated)
                        VALUES (?, ?, ?, ?, ?, ?, ?)""";
                
                // For MySQL, use ON DUPLICATE KEY UPDATE instead
                if (plugin.getConfigManager().getDatabaseType().equalsIgnoreCase("mysql")) {
                    sql = """
                            INSERT INTO vctime_data 
                            (uuid, discord_id, total_time, current_session_start, last_reward_tier, in_voice_channel, last_updated)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                            ON DUPLICATE KEY UPDATE
                            discord_id = VALUES(discord_id),
                            total_time = VALUES(total_time),
                            current_session_start = VALUES(current_session_start),
                            last_reward_tier = VALUES(last_reward_tier),
                            in_voice_channel = VALUES(in_voice_channel),
                            last_updated = VALUES(last_updated)""";
                }
                
                try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                    stmt.setString(1, data.getUuid().toString());
                    stmt.setString(2, data.getDiscordId());
                    stmt.setLong(3, data.getTotalTime());
                    stmt.setLong(4, data.getCurrentSessionStart());
                    stmt.setInt(5, data.getLastRewardTier());
                    stmt.setBoolean(6, data.isInVoiceChannel());
                    stmt.setLong(7, System.currentTimeMillis());
                    
                    stmt.executeUpdate();
                }
                
                playerCache.put(data.getUuid(), data);
                
                if (plugin.getConfigManager().isDebugMode()) {
                    plugin.getPluginLogger().debug("Saved data for player: " + data.getUuid());
                }
                
            } catch (SQLException e) {
                plugin.getPluginLogger().error("Failed to save player data: " + e.getMessage());
            }
        });
    }
    
    public CompletableFuture<PlayerData> getPlayerDataByDiscordId(String discordId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String sql = "SELECT * FROM vctime_data WHERE discord_id = ?";
                try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                    stmt.setString(1, discordId);
                    
                    try (ResultSet rs = stmt.executeQuery()) {
                        if (rs.next()) {
                            UUID uuid = UUID.fromString(rs.getString("uuid"));
                            PlayerData data = new PlayerData(
                                    uuid,
                                    rs.getString("discord_id"),
                                    rs.getLong("total_time"),
                                    rs.getLong("current_session_start"),
                                    rs.getInt("last_reward_tier"),
                                    rs.getBoolean("in_voice_channel"),
                                    rs.getLong("last_updated")
                            );
                            
                            playerCache.put(uuid, data);
                            return data;
                        }
                    }
                }
            } catch (SQLException e) {
                plugin.getPluginLogger().error("Failed to get player data by Discord ID: " + e.getMessage());
            }
            
            return null;
        });
    }
    
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                plugin.getPluginLogger().info("Database connection closed");
            }
        } catch (SQLException e) {
            plugin.getPluginLogger().error("Failed to close database connection: " + e.getMessage());
        }
    }
    
    public Map<UUID, PlayerData> getPlayerCache() {
        return playerCache;
    }
}