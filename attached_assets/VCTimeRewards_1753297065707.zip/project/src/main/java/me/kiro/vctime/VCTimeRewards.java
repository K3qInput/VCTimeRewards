package me.kiro.vctime;

import me.kiro.vctime.commands.VCTimeCommand;
import me.kiro.vctime.config.ConfigManager;
import me.kiro.vctime.database.DatabaseManager;
import me.kiro.vctime.discord.DiscordListener;
import me.kiro.vctime.placeholders.VCTimePlaceholderExpansion;
import me.kiro.vctime.rewards.RewardManager;
import me.kiro.vctime.utils.Logger;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class VCTimeRewards extends JavaPlugin {
    
    private static VCTimeRewards instance;
    private ConfigManager configManager;
    private DatabaseManager databaseManager;
    private RewardManager rewardManager;
    private DiscordListener discordListener;
    private Logger logger;
    
    @Override
    public void onEnable() {
        instance = this;
        
        // Initialize logger
        logger = new Logger(this);
        
        // Check for DiscordSRV
        if (!checkDiscordSRV()) {
            logger.error("DiscordSRV not found! This plugin requires DiscordSRV to function.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // Initialize components
        configManager = new ConfigManager(this);
        databaseManager = new DatabaseManager(this);
        rewardManager = new RewardManager(this);
        
        // Initialize database
        if (!databaseManager.initialize()) {
            logger.error("Failed to initialize database! Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // Initialize Discord listener
        discordListener = new DiscordListener(this);
        discordListener.initialize();
        
        // Register commands
        getCommand("vctime").setExecutor(new VCTimeCommand(this));
        
        // Register PlaceholderAPI expansion
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new VCTimePlaceholderExpansion(this).register();
            logger.info("PlaceholderAPI integration enabled!");
        }
        
        logger.info("VCTimeRewards v" + getDescription().getVersion() + " has been enabled!");
        logger.info("Plugin by kiro.java - Thank you for using VCTimeRewards!");
    }
    
    @Override
    public void onDisable() {
        if (discordListener != null) {
            discordListener.shutdown();
        }
        
        if (databaseManager != null) {
            databaseManager.close();
        }
        
        logger.info("VCTimeRewards has been disabled!");
    }
    
    private boolean checkDiscordSRV() {
        return Bukkit.getPluginManager().isPluginEnabled("DiscordSRV");
    }
    
    public void reload() {
        configManager.reload();
        rewardManager.reload();
        logger.info("VCTimeRewards configuration reloaded!");
    }
    
    // Getters
    public static VCTimeRewards getInstance() {
        return instance;
    }
    
    public ConfigManager getConfigManager() {
        return configManager;
    }
    
    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }
    
    public RewardManager getRewardManager() {
        return rewardManager;
    }
    
    public Logger getPluginLogger() {
        return logger;
    }
}