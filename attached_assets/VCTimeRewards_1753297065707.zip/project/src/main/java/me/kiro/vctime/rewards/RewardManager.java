package me.kiro.vctime.rewards;

import me.kiro.vctime.VCTimeRewards;
import me.kiro.vctime.models.PlayerData;
import me.kiro.vctime.utils.TimeUtils;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.TimeUnit;

public class RewardManager {
    
    private final VCTimeRewards plugin;
    private final Map<Integer, RewardTier> rewardTiers = new HashMap<>();
    
    public RewardManager(VCTimeRewards plugin) {
        this.plugin = plugin;
        loadRewards();
    }
    
    public void loadRewards() {
        rewardTiers.clear();
        
        ConfigurationSection rewardsSection = plugin.getConfigManager().getRewardsConfig().getConfigurationSection("rewards");
        if (rewardsSection == null) {
            plugin.getPluginLogger().warn("No rewards configuration found!");
            return;
        }
        
        for (String key : rewardsSection.getKeys(false)) {
            try {
                int minutes = Integer.parseInt(key);
                ConfigurationSection tierSection = rewardsSection.getConfigurationSection(key);
                
                if (tierSection != null && tierSection.getBoolean("enabled", true)) {
                    List<String> commands = tierSection.getStringList("commands");
                    rewardTiers.put(minutes, new RewardTier(minutes, commands));
                    
                    if (plugin.getConfigManager().isDebugMode()) {
                        plugin.getPluginLogger().debug("Loaded reward tier: " + minutes + " minutes with " + commands.size() + " commands");
                    }
                }
            } catch (NumberFormatException e) {
                plugin.getPluginLogger().warn("Invalid reward tier key: " + key);
            }
        }
        
        plugin.getPluginLogger().info("Loaded " + rewardTiers.size() + " reward tiers");
    }
    
    public void reload() {
        loadRewards();
    }
    
    public void checkRewards(UUID playerUuid, PlayerData data) {
        Player player = Bukkit.getPlayer(playerUuid);
        if (player == null || !player.isOnline()) return;
        
        long totalMinutes = TimeUnit.MILLISECONDS.toMinutes(data.getTotalTimeWithCurrentSession());
        int currentTier = (int) totalMinutes;
        
        // Find the highest tier the player qualifies for that they haven't received yet
        List<Integer> eligibleTiers = new ArrayList<>();
        for (int tier : rewardTiers.keySet()) {
            if (tier <= currentTier && tier > data.getLastRewardTier()) {
                eligibleTiers.add(tier);
            }
        }
        
        // Sort tiers and give rewards in order
        eligibleTiers.sort(Integer::compareTo);
        
        for (int tier : eligibleTiers) {
            giveReward(player, rewardTiers.get(tier));
            data.setLastRewardTier(tier);
            plugin.getDatabaseManager().savePlayerData(data);
            
            if (plugin.getConfigManager().isDebugMode()) {
                plugin.getPluginLogger().debug("Gave " + tier + " minute reward to " + player.getName());
            }
        }
    }
    
    private void giveReward(Player player, RewardTier tier) {
        // Announce reward to player
        if (plugin.getConfigManager().getRewardsConfig().getBoolean("settings.announce-to-player", true)) {
            String message = plugin.getConfig().getString("messages.reward-received", "&aYou received a reward for spending &e%time% &ain voice chat!");
            message = message.replace("%time%", tier.getMinutes() + " minutes");
            player.sendMessage(plugin.getConfigManager().getRewardsConfig().getString("messages.prefix", "&8[&6VCTimeRewards&8] &r") + message);
        }
        
        // Execute reward commands
        for (String command : tier.getCommands()) {
            String processedCommand = command.replace("%player%", player.getName());
            
            Bukkit.getScheduler().runTask(plugin, () -> {
                try {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
                    
                    if (plugin.getConfigManager().isDebugMode()) {
                        plugin.getPluginLogger().debug("Executed reward command: " + processedCommand);
                    }
                } catch (Exception e) {
                    plugin.getPluginLogger().error("Failed to execute reward command: " + processedCommand);
                    plugin.getPluginLogger().error("Error: " + e.getMessage());
                }
            });
        }
        
        // Log reward giving
        if (plugin.getConfigManager().getRewardsConfig().getBoolean("settings.log-rewards", true)) {
            plugin.getPluginLogger().info("Gave " + tier.getMinutes() + " minute reward to " + player.getName());
        }
    }
    
    public int getNextRewardTier(PlayerData data) {
        long totalMinutes = TimeUnit.MILLISECONDS.toMinutes(data.getTotalTimeWithCurrentSession());
        int currentTier = (int) totalMinutes;
        
        return rewardTiers.keySet().stream()
                .filter(tier -> tier > Math.max(currentTier, data.getLastRewardTier()))
                .min(Integer::compareTo)
                .orElse(-1);
    }
    
    public Map<Integer, RewardTier> getRewardTiers() {
        return Collections.unmodifiableMap(rewardTiers);
    }
    
    public static class RewardTier {
        private final int minutes;
        private final List<String> commands;
        
        public RewardTier(int minutes, List<String> commands) {
            this.minutes = minutes;
            this.commands = new ArrayList<>(commands);
        }
        
        public int getMinutes() {
            return minutes;
        }
        
        public List<String> getCommands() {
            return Collections.unmodifiableList(commands);
        }
    }
}