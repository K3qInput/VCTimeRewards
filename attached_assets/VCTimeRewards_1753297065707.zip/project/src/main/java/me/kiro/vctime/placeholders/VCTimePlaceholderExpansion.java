package me.kiro.vctime.placeholders;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.kiro.vctime.VCTimeRewards;
import me.kiro.vctime.models.PlayerData;
import me.kiro.vctime.utils.TimeUtils;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.TimeUnit;

public class VCTimePlaceholderExpansion extends PlaceholderExpansion {
    
    private final VCTimeRewards plugin;
    
    public VCTimePlaceholderExpansion(VCTimeRewards plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public @NotNull String getIdentifier() {
        return "vctime";
    }
    
    @Override
    public @NotNull String getAuthor() {
        return "kiro.java";
    }
    
    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }
    
    @Override
    public boolean persist() {
        return true;
    }
    
    @Override
    public String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";
        
        // Get player data from cache or return default values
        PlayerData data = plugin.getDatabaseManager().getPlayerCache().get(player.getUniqueId());
        if (data == null) {
            // Return default values for unknown players
            switch (params.toLowerCase()) {
                case "total":
                    return "0m";
                case "total_raw":
                    return "0";
                case "current_session":
                    return "0m";
                case "current_session_raw":
                    return "0";
                case "next_reward":
                    return "Unknown";
                case "next_reward_raw":
                    return "0";
                case "last_reward":
                    return "0";
                case "linked":
                    return "No";
                default:
                    return "";
            }
        }
        
        switch (params.toLowerCase()) {
            case "total":
                return TimeUtils.formatTime(data.getTotalTimeWithCurrentSession());
                
            case "total_raw":
                return String.valueOf(TimeUnit.MILLISECONDS.toMinutes(data.getTotalTimeWithCurrentSession()));
                
            case "current_session":
                return data.isInVoiceChannel() ? TimeUtils.formatTime(data.getCurrentSessionTime()) : "0m";
                
            case "current_session_raw":
                return String.valueOf(TimeUnit.MILLISECONDS.toMinutes(data.getCurrentSessionTime()));
                
            case "next_reward":
                int nextTier = plugin.getRewardManager().getNextRewardTier(data);
                if (nextTier == -1) {
                    return "No more rewards";
                }
                long currentMinutes = TimeUnit.MILLISECONDS.toMinutes(data.getTotalTimeWithCurrentSession());
                long timeToNext = (nextTier - currentMinutes) * 60000; // Convert to milliseconds
                return timeToNext > 0 ? TimeUtils.formatTime(timeToNext) : "Available now";
                
            case "next_reward_raw":
                int nextTierRaw = plugin.getRewardManager().getNextRewardTier(data);
                if (nextTierRaw == -1) {
                    return "0";
                }
                long currentMinutesRaw = TimeUnit.MILLISECONDS.toMinutes(data.getTotalTimeWithCurrentSession());
                long timeToNextRaw = nextTierRaw - currentMinutesRaw;
                return String.valueOf(Math.max(0, timeToNextRaw));
                
            case "last_reward":
                return String.valueOf(data.getLastRewardTier());
                
            case "linked":
                return data.getDiscordId() != null ? "Yes" : "No";
                
            default:
                return "";
        }
    }
}