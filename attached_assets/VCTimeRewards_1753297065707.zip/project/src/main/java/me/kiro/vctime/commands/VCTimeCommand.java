package me.kiro.vctime.commands;

import me.kiro.vctime.VCTimeRewards;
import me.kiro.vctime.models.PlayerData;
import me.kiro.vctime.utils.TimeUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class VCTimeCommand implements CommandExecutor, TabCompleter {
    
    private final VCTimeRewards plugin;
    
    public VCTimeCommand(VCTimeRewards plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player) {
                return handleStats(sender, args);
            } else {
                return handleHelp(sender);
            }
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "stats":
                return handleStats(sender, args);
            case "reload":
                return handleReload(sender);
            case "help":
                return handleHelp(sender);
            default:
                sender.sendMessage(getPrefix() + "§cUnknown command. Use /vctime help for available commands.");
                return true;
        }
    }
    
    private boolean handleStats(CommandSender sender, String[] args) {
        if (!sender.hasPermission("vctime.stats")) {
            sender.sendMessage(getPrefix() + plugin.getConfig().getString("messages.no-permission"));
            return true;
        }
        
        Player target;
        if (args.length > 1 && sender.hasPermission("vctime.admin")) {
            target = plugin.getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(getPrefix() + "§cPlayer not found!");
                return true;
            }
        } else if (sender instanceof Player) {
            target = (Player) sender;
        } else {
            sender.sendMessage(getPrefix() + "§cYou must specify a player name from console!");
            return true;
        }
        
        plugin.getDatabaseManager().getPlayerData(target.getUniqueId()).thenAccept(data -> {
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                sendStats(sender, target, data);
            });
        });
        
        return true;
    }
    
    private void sendStats(CommandSender sender, Player target, PlayerData data) {
        // Check if player is linked
        boolean isLinked = data.getDiscordId() != null;
        
        // Calculate times
        long totalTime = data.getTotalTimeWithCurrentSession();
        long currentSession = data.getCurrentSessionTime();
        
        // Get next reward info
        int nextRewardTier = plugin.getRewardManager().getNextRewardTier(data);
        long nextRewardMinutes = nextRewardTier != -1 ? nextRewardTier : 0;
        long currentMinutes = TimeUnit.MILLISECONDS.toMinutes(totalTime);
        long timeToNextReward = nextRewardTier != -1 ? (nextRewardMinutes - currentMinutes) : 0;
        
        // Send stats
        sender.sendMessage(plugin.getConfig().getString("messages.stats.header", "§6§l=== VCTime Statistics ==="));
        
        String targetName = target.getName();
        if (!sender.equals(target)) {
            sender.sendMessage("§ePlayer: §a" + targetName);
        }
        
        String totalTimeStr = plugin.getConfig().getString("messages.stats.total-time", "§eTotal VC Time: §a%vctime_total%");
        totalTimeStr = totalTimeStr.replace("%vctime_total%", TimeUtils.formatTime(totalTime));
        sender.sendMessage(totalTimeStr);
        
        String currentSessionStr = plugin.getConfig().getString("messages.stats.current-session", "§eCurrent Session: §a%vctime_current_session%");
        currentSessionStr = currentSessionStr.replace("%vctime_current_session%", data.isInVoiceChannel() ? TimeUtils.formatTime(currentSession) : "Not in VC");
        sender.sendMessage(currentSessionStr);
        
        String nextRewardStr = plugin.getConfig().getString("messages.stats.next-reward", "§eNext Reward In: §a%vctime_next_reward%");
        nextRewardStr = nextRewardStr.replace("%vctime_next_reward%", nextRewardTier != -1 ? TimeUtils.formatTime(timeToNextReward * 60000) : "No more rewards");
        sender.sendMessage(nextRewardStr);
        
        String lastRewardStr = plugin.getConfig().getString("messages.stats.last-reward", "§eLast Reward Tier: §a%vctime_last_reward% minutes");
        lastRewardStr = lastRewardStr.replace("%vctime_last_reward%", String.valueOf(data.getLastRewardTier()));
        sender.sendMessage(lastRewardStr);
        
        String linkedStr = plugin.getConfig().getString("messages.stats.linked-status", "§eDiscord Linked: §a%vctime_linked%");
        linkedStr = linkedStr.replace("%vctime_linked%", isLinked ? "Yes" : "No");
        sender.sendMessage(linkedStr);
        
        sender.sendMessage(plugin.getConfig().getString("messages.stats.footer", "§6§l======================="));
    }
    
    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission("vctime.reload")) {
            sender.sendMessage(getPrefix() + plugin.getConfig().getString("messages.no-permission"));
            return true;
        }
        
        plugin.reload();
        sender.sendMessage(getPrefix() + plugin.getConfig().getString("messages.reload-success"));
        return true;
    }
    
    private boolean handleHelp(CommandSender sender) {
        sender.sendMessage("§6§l=== VCTimeRewards Commands ===");
        sender.sendMessage("§e/vctime §8- §7Show your VC time statistics");
        sender.sendMessage("§e/vctime stats [player] §8- §7Show VC time statistics");
        
        if (sender.hasPermission("vctime.admin")) {
            sender.sendMessage("§e/vctime reload §8- §7Reload plugin configuration");
        }
        
        sender.sendMessage("§e/vctime help §8- §7Show this help message");
        sender.sendMessage("§6§l============================");
        return true;
    }
    
    private String getPrefix() {
        return plugin.getConfig().getString("messages.prefix", "§8[§6VCTimeRewards§8] §r");
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (args.length == 1) {
            List<String> subCommands = Arrays.asList("stats", "help");
            if (sender.hasPermission("vctime.reload")) {
                subCommands = Arrays.asList("stats", "reload", "help");
            }
            
            for (String sub : subCommands) {
                if (sub.toLowerCase().startsWith(args[0].toLowerCase())) {
                    completions.add(sub);
                }
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("stats") && sender.hasPermission("vctime.admin")) {
            // Tab complete player names for stats command
            for (Player player : plugin.getServer().getOnlinePlayers()) {
                if (player.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                    completions.add(player.getName());
                }
            }
        }
        
        return completions;
    }
}