package me.kiro.vctime.discord;

import github.scarsz.discordsrv.DiscordSRV;
import github.scarsz.discordsrv.api.Subscribe;
import github.scarsz.discordsrv.api.events.DiscordGuildVoiceJoinEvent;
import github.scarsz.discordsrv.api.events.DiscordGuildVoiceLeaveEvent;
import github.scarsz.discordsrv.api.events.DiscordGuildVoiceMoveEvent;
import github.scarsz.discordsrv.util.DiscordUtil;
import me.kiro.vctime.VCTimeRewards;
import me.kiro.vctime.models.PlayerData;
import me.kiro.vctime.utils.TimeUtils;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.channel.concrete.VoiceChannel;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;

public class DiscordListener {
    
    private final VCTimeRewards plugin;
    
    public DiscordListener(VCTimeRewards plugin) {
        this.plugin = plugin;
    }
    
    public void initialize() {
        DiscordSRV.api.subscribe(this);
        plugin.getPluginLogger().info("Discord listener initialized and subscribed to DiscordSRV events");
    }
    
    public void shutdown() {
        DiscordSRV.api.unsubscribe(this);
        plugin.getPluginLogger().info("Discord listener unsubscribed from DiscordSRV events");
    }
    
    @Subscribe
    public void onVoiceJoin(DiscordGuildVoiceJoinEvent event) {
        if (!isTrackedChannel(event.getChannel())) return;
        
        handleVoiceJoin(event.getMember(), event.getChannel());
    }
    
    @Subscribe
    public void onVoiceMove(DiscordGuildVoiceMoveEvent event) {
        boolean wasTracked = isTrackedChannel(event.getChannelLeft());
        boolean isTracked = isTrackedChannel(event.getChannelJoined());
        
        if (wasTracked && !isTracked) {
            // Left a tracked channel
            handleVoiceLeave(event.getMember(), event.getChannelLeft());
        } else if (!wasTracked && isTracked) {
            // Joined a tracked channel
            handleVoiceJoin(event.getMember(), event.getChannelJoined());
        }
        // If moving between tracked channels, no action needed (session continues)
    }
    
    @Subscribe
    public void onVoiceLeave(DiscordGuildVoiceLeaveEvent event) {
        if (!isTrackedChannel(event.getChannel())) return;
        
        handleVoiceLeave(event.getMember(), event.getChannel());
    }
    
    private void handleVoiceJoin(Member member, VoiceChannel channel) {
        String discordId = member.getId();
        UUID playerUuid = DiscordSRV.getPlugin().getAccountLinkManager().getUuid(discordId);
        
        if (playerUuid == null) {
            if (plugin.getConfigManager().isDebugMode()) {
                plugin.getPluginLogger().debug("Discord user " + member.getEffectiveName() + " is not linked to a Minecraft account");
            }
            return;
        }
        
        // Check if player needs to be online in Minecraft
        if (plugin.getConfigManager().requireMinecraftOnline()) {
            Player player = Bukkit.getPlayer(playerUuid);
            if (player == null || !player.isOnline()) {
                if (plugin.getConfigManager().isDebugMode()) {
                    plugin.getPluginLogger().debug("Player " + playerUuid + " is not online in Minecraft, ignoring VC join");
                }
                return;
            }
        }
        
        // Check if user should be ignored (muted/deafened)
        if (shouldIgnoreUser(member)) {
            if (plugin.getConfigManager().isDebugMode()) {
                plugin.getPluginLogger().debug("Ignoring user " + member.getEffectiveName() + " (muted/deafened)");
            }
            return;
        }
        
        plugin.getDatabaseManager().getPlayerData(playerUuid).thenAccept(data -> {
            data.setDiscordId(discordId);
            data.startVoiceSession();
            plugin.getDatabaseManager().savePlayerData(data);
            
            if (plugin.getConfigManager().isDebugMode()) {
                plugin.getPluginLogger().debug("Started VC session for " + member.getEffectiveName() + " in channel " + channel.getName());
            }
        });
    }
    
    private void handleVoiceLeave(Member member, VoiceChannel channel) {
        String discordId = member.getId();
        UUID playerUuid = DiscordSRV.getPlugin().getAccountLinkManager().getUuid(discordId);
        
        if (playerUuid == null) return;
        
        plugin.getDatabaseManager().getPlayerData(playerUuid).thenAccept(data -> {
            if (data.isInVoiceChannel()) {
                data.endVoiceSession();
                plugin.getDatabaseManager().savePlayerData(data);
                
                // Check for rewards
                plugin.getRewardManager().checkRewards(playerUuid, data);
                
                if (plugin.getConfigManager().isDebugMode()) {
                    long sessionTime = data.getCurrentSessionTime();
                    plugin.getPluginLogger().debug("Ended VC session for " + member.getEffectiveName() + 
                                                 " (Session: " + TimeUtils.formatTime(sessionTime) + 
                                                 ", Total: " + TimeUtils.formatTime(data.getTotalTime()) + ")");
                }
            }
        });
    }
    
    private boolean isTrackedChannel(VoiceChannel channel) {
        if (channel == null) return false;
        
        List<String> trackedChannels = plugin.getConfigManager().getTrackedChannels();
        return trackedChannels.contains(channel.getId());
    }
    
    private boolean shouldIgnoreUser(Member member) {
        if (plugin.getConfigManager().isIgnoreWhenMuted() && member.getVoiceState() != null && member.getVoiceState().isMuted()) {
            return true;
        }
        
        if (plugin.getConfigManager().isIgnoreWhenDeafened() && member.getVoiceState() != null && member.getVoiceState().isDeafened()) {
            return true;
        }
        
        return false;
    }
}