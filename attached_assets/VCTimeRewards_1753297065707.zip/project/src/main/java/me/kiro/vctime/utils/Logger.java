package me.kiro.vctime.utils;

import me.kiro.vctime.VCTimeRewards;
import org.bukkit.ChatColor;

public class Logger {
    
    private final VCTimeRewards plugin;
    private final String prefix;
    
    public Logger(VCTimeRewards plugin) {
        this.plugin = plugin;
        this.prefix = "[VCTimeRewards] ";
    }
    
    public void info(String message) {
        plugin.getLogger().info(message);
    }
    
    public void warn(String message) {
        plugin.getLogger().warning(message);
    }
    
    public void error(String message) {
        plugin.getLogger().severe(message);
    }
    
    public void debug(String message) {
        if (plugin.getConfigManager() != null && plugin.getConfigManager().isDebugMode()) {
            plugin.getLogger().info("[DEBUG] " + message);
        }
    }
    
    public void log(LogLevel level, String message) {
        switch (level) {
            case INFO:
                info(message);
                break;
            case WARN:
                warn(message);
                break;
            case ERROR:
                error(message);
                break;
            case DEBUG:
                debug(message);
                break;
        }
    }
    
    public enum LogLevel {
        INFO, WARN, ERROR, DEBUG
    }
}