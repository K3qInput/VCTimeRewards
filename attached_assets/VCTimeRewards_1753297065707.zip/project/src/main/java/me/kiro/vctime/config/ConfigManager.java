package me.kiro.vctime.config;

import me.kiro.vctime.VCTimeRewards;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class ConfigManager {
    
    private final VCTimeRewards plugin;
    private FileConfiguration config;
    private FileConfiguration rewardsConfig;
    
    public ConfigManager(VCTimeRewards plugin) {
        this.plugin = plugin;
        loadConfigs();
    }
    
    private void loadConfigs() {
        // Save default configs
        plugin.saveDefaultConfig();
        saveDefaultRewardsConfig();
        
        // Load configs
        config = plugin.getConfig();
        rewardsConfig = loadRewardsConfig();
    }
    
    private void saveDefaultRewardsConfig() {
        File rewardsFile = new File(plugin.getDataFolder(), "rewards.yml");
        if (!rewardsFile.exists()) {
            plugin.saveResource("rewards.yml", false);
        }
    }
    
    private FileConfiguration loadRewardsConfig() {
        File rewardsFile = new File(plugin.getDataFolder(), "rewards.yml");
        return YamlConfiguration.loadConfiguration(rewardsFile);
    }
    
    public void reload() {
        plugin.reloadConfig();
        config = plugin.getConfig();
        rewardsConfig = loadRewardsConfig();
    }
    
    // Database settings
    public String getDatabaseType() {
        return config.getString("database.type", "sqlite");
    }
    
    public String getDatabaseHost() {
        return config.getString("database.mysql.host", "localhost");
    }
    
    public int getDatabasePort() {
        return config.getInt("database.mysql.port", 3306);
    }
    
    public String getDatabaseName() {
        return config.getString("database.mysql.database", "vctime");
    }
    
    public String getDatabaseUsername() {
        return config.getString("database.mysql.username", "root");
    }
    
    public String getDatabasePassword() {
        return config.getString("database.mysql.password", "");
    }
    
    // Voice channel settings
    public List<String> getTrackedChannels() {
        return config.getStringList("discord.tracked-channels");
    }
    
    public boolean isIgnoreWhenMuted() {
        return config.getBoolean("discord.ignore-when-muted", true);
    }
    
    public boolean isIgnoreWhenDeafened() {
        return config.getBoolean("discord.ignore-when-deafened", true);
    }
    
    public boolean requireMinecraftOnline() {
        return config.getBoolean("discord.require-minecraft-online", false);
    }
    
    // General settings
    public boolean isDebugMode() {
        return config.getBoolean("settings.debug", false);
    }
    
    public int getSaveInterval() {
        return config.getInt("settings.save-interval", 300);
    }
    
    // Rewards config
    public FileConfiguration getRewardsConfig() {
        return rewardsConfig;
    }
}