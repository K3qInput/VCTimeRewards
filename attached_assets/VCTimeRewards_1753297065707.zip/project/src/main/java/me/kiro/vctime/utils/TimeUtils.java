package me.kiro.vctime.utils;

import java.util.concurrent.TimeUnit;

public class TimeUtils {
    
    public static String formatTime(long milliseconds) {
        if (milliseconds <= 0) {
            return "0m";
        }
        
        long totalMinutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
        long hours = totalMinutes / 60;
        long minutes = totalMinutes % 60;
        
        if (hours > 0) {
            return hours + "h " + minutes + "m";
        } else {
            return minutes + "m";
        }
    }
    
    public static String formatDetailedTime(long milliseconds) {
        if (milliseconds <= 0) {
            return "0 minutes";
        }
        
        long totalMinutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
        long hours = totalMinutes / 60;
        long minutes = totalMinutes % 60;
        
        StringBuilder sb = new StringBuilder();
        
        if (hours > 0) {
            sb.append(hours).append(hours == 1 ? " hour" : " hours");
            if (minutes > 0) {
                sb.append(" and ");
            }
        }
        
        if (minutes > 0 || hours == 0) {
            sb.append(minutes).append(minutes == 1 ? " minute" : " minutes");
        }
        
        return sb.toString();
    }
    
    public static long parseTime(String timeString) {
        timeString = timeString.toLowerCase().trim();
        
        long totalMinutes = 0;
        
        // Parse hours
        if (timeString.contains("h")) {
            String[] parts = timeString.split("h");
            try {
                long hours = Long.parseLong(parts[0].trim());
                totalMinutes += hours * 60;
                timeString = parts.length > 1 ? parts[1].trim() : "";
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        
        // Parse minutes
        if (timeString.contains("m")) {
            String minutesPart = timeString.replace("m", "").trim();
            if (!minutesPart.isEmpty()) {
                try {
                    long minutes = Long.parseLong(minutesPart);
                    totalMinutes += minutes;
                } catch (NumberFormatException e) {
                    return 0;
                }
            }
        } else if (!timeString.isEmpty()) {
            // Assume it's just minutes if no unit specified
            try {
                long minutes = Long.parseLong(timeString);
                totalMinutes += minutes;
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        
        return TimeUnit.MINUTES.toMillis(totalMinutes);
    }
}